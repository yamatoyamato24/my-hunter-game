import pygame
import asyncio
import math
import datetime # requestsの代わりにこれを使います
import random

def get_time_weather():
    # 現在の「時」を取得 (0〜23)
    # 日本時間で判定されます
    now_hour = datetime.datetime.now().hour
    
    if 6 <= now_hour < 16:
        return "Clear"   # 6時〜15時：昼間（晴れ）
    elif 16 <= now_hour < 19:
        return "Clouds"  # 16時〜18時：夕方（くもり・オレンジ風）
    else:
    # --- 夜の判定 ---
        # 0.0 〜 1.0 のランダムな数字を引き、0.3未満（30%）なら雨にする
        if random.random() < 0.3:
            return "Rain"
        else:
            return "Night"

# --- 画像読み込み関数（縦横比を維持） ---
def load_game_image(path, target_width):
    try:
        img = pygame.image.load(path).convert_alpha()
        org_width, org_height = img.get_size()
        aspect_ratio = org_height / org_width
        target_height = int(target_width * aspect_ratio)
        return pygame.transform.scale(img, (target_width, target_height))
    except:
        surf = pygame.Surface((target_width, target_width))
        surf.fill((200, 200, 200))
        return surf

class WeatherEffect:
    def __init__(self, weather_type):
        self.weather = weather_type
        self.particles = []
        # 雲のデータ（雨と曇りの時だけ使う）
        self.clouds = []
        if self.weather in ["Rain","Clouds"]:
            for _ in range(5): # 5個くらいの雲
                self.clouds.append({"x": random.randint(0, 800), "y": random.randint(0, 150), "w": 300, "h": 100, "speed": 0.3})

        # 粒（雨や雪）のエフェクト生成
        for _ in range(60):
            self.particles.append({
                "x": random.randint(0, 800),
                "y": random.randint(0, 1500),
                "speed": random.uniform(1, 3),
                "size": random.randint(1, 3),
                "alpha": random.randint(100, 255) # またたき用
            })

    def update(self):
        # 雲の移動
        for c in self.clouds:
            c["x"] += c["speed"]
            if c["x"] > 800: c["x"] = -300
        # 雲をゆっくり動かす
        for p in self.particles:
            if self.weather == "Rain":
                p["y"] += p["speed"] # 雨は下に落ちる
            elif self.weather == "Night":
                p["alpha"] = random.randint(100, 255) # 星はまたたく
            elif self.weather == "Clear":
                p["y"] -= p["speed"] * 0.5 # 昼は上昇
            elif self.weather == "Clouds":
                p["x"] -= p["speed"] # 夕方は横
            
            # 画面外ループ
            if p["y"] > 1500: p["y"] = -20
            if p["y"] < -20: p["y"] = 1500
            if p["x"] < -20: p["x"] = 800
            if p["x"] > 820: p["x"] = -20

    def draw(self, screen):
        # 1. 雲の描画
        for c in self.clouds:
            cloud_surf = pygame.Surface((c["w"], c["h"]), pygame.SRCALPHA)
            color = (20, 20, 40, 160) if self.weather == "Rain" else (100, 100, 100, 140)
            pygame.draw.ellipse(cloud_surf, color, (0, 0, c["w"], c["h"]))
            screen.blit(cloud_surf, (c["x"], c["y"]))
        
        # 2 粒の描画
        for p in self.particles:
            if self.weather == "Rain":
                # 雨の線を描画
                pygame.draw.line(screen, (120, 120, 255), (p["x"], p["y"]), (p["x"], p["y"]+15), 1)
            elif self.weather == "Night":
                s = pygame.Surface((p["size"]*2, p["size"]*2), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 255, 200, p["alpha"]), (p["size"], p["size"]), p["size"])
                screen.blit(s, (p["x"], p["y"]))
            elif self.weather == "Clear":
                pygame.draw.circle(screen, (255, 255, 200, 150), (int(p["x"]), int(p["y"])), 2)
            elif self.weather == "Clouds":
                pygame.draw.rect(screen, (210, 105, 30), (p["x"], p["y"], 8, 4))


        for p in self.particles:
            if self.weather == "Night":
                # 夜：キラキラ光る星を描画
                s = pygame.Surface((p["size"]*2, p["size"]*2), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 255, 200, p["alpha"]), (p["size"], p["size"]), p["size"])
                screen.blit(s, (p["x"], p["y"]))
            elif self.weather == "Clear":
                # 昼：光の粉
                pygame.draw.circle(screen, (255, 255, 200, 150), (int(p["x"]), int(p["y"])), 2)
            elif self.weather == "Clouds":
                # 夕方：落ち葉
                pygame.draw.rect(screen, (210, 105, 30), (p["x"], p["y"], 8, 4))
       
class Player:
    def __init__(self):
        self.image = load_game_image("assets/run_away.png", 60)
        self.rect = self.image.get_rect(center=(400, 300))
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = 10
        self.hp = 3
        self.invincible_timer = 0 

    def update(self, move_vec=(0, 0)):
        # キーボード操作
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:    self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:  self.rect.y += self.speed
        if keys[pygame.K_LEFT]:  self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]: self.rect.x += self.speed

        # タッチ操作（引数で移動ベクトルを受け取る）
        self.rect.x += move_vec[0] * self.speed
        self.rect.y += move_vec[1] * self.speed

        # 画面の下端(1500)まで動けるように修正
        self.rect.clamp_ip(pygame.Rect(0, 0, 800, 1500))

        if self.invincible_timer > 0: 
            self.invincible_timer -= 1

        self.rect.clamp_ip(pygame.Rect(0, 0, 800, 1500))

    def draw(self, screen):
        # 無敵時間中（ダメージを受けた後）の演出
        if self.invincible_timer > 0:
            # 10フレームごとに点滅（チカチカさせる）
            if self.invincible_timer % 10 < 5: 
                # 1. 画像のコピーを作る（元の画像を変えないため）
                temp_image = self.image.copy()
                
                # 2. 赤色で塗りつぶして合成する
                # (255, 100, 100) は少し明るい赤。真っ赤なら (255, 0, 0)
                temp_image.fill((255, 150, 150), special_flags=pygame.BLEND_RGBA_MULT)
                
                # 3. 赤くなった画像を表示
                screen.blit(temp_image, self.rect)
        else:
            # 通常時はそのまま表示
            screen.blit(self.image, self.rect)



class Enemy:
    def __init__(self):
        self.image = load_game_image("assets/enemy.png", 300)
        self.rect = self.image.get_rect(topleft=(20, 20))
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = 5

    def update(self, player_rect):
        if self.rect.x < player_rect.x: self.rect.x += self.speed
        if self.rect.x > player_rect.x: self.rect.x -= self.speed
        if self.rect.y < player_rect.y: self.rect.y += self.speed
        if self.rect.y > player_rect.y: self.rect.y -= self.speed

    def draw(self, screen):
        screen.blit(self.image, self.rect)


class Background:
    def __init__(self,weather): #引数を追加
        self.weather = weather
        # 通信不要の時間帯判定に切り替え

        colors = {
            "Clear": (135, 206, 235),  # 昼：スカイブルー
            "Clouds": (255, 140, 0),   # 夕方：オレンジ（夕焼け風に変更！）
            "Rain": (25, 25, 112),     # 夜：ミッドナイトブルー
            "Snow": (240, 248, 255)    # 雪：アリスブルー（冬の朝など用）
        }
        self.base_color = colors.get(self.weather, (34, 139, 34))

        # 3. 背景画像の読み込みと合成
        try:
            raw_img = pygame.image.load("assets/background.png").convert()
            self.image = pygame.transform.scale(raw_img, (800, 1500))
            
            # 時間帯の色の「薄い膜」を乗せる
            self.overlay = pygame.Surface(800, 1500)
            self.overlay.fill(self.base_color)
            # 透明度をここで設定（0〜255。100くらいが画像も見えて丁度いいです）
            self.overlay.set_alpha(100) 

        except:
            self.image = pygame.Surface((800, 1500))
            self.image.fill(self.base_color)
            self.overlay = None # 画像がない場合はオーバーレイ不要

    def draw(self, screen):
        screen.blit(self.image, (0, 0))
        # その上に色付きの膜を重ねて描く（これで確実に色が変わります）
        if self.overlay:
            screen.blit(self.overlay, (0, 0))


class Controller:
    def __init__(self):
        # 配置設定
        self.cx, self.cy = 400, 1200 
        self.pad_radius = 220 
        self.font = pygame.font.SysFont(None, 70)

    def get_input(self):
        """8方向判定用（今の移動ロジックで使用）"""
        m_pos = pygame.mouse.get_pos()
        m_pressed = pygame.mouse.get_pressed()[0]
        res = {"up": False, "down": False, "left": False, "right": False}
        
        if m_pressed:
            dx = m_pos[0] - self.cx
            dy = m_pos[1] - self.cy
            dist_sq = dx**2 + dy**2

            if 10**2 < dist_sq < self.pad_radius**2:
                deg = math.degrees(math.atan2(dy, dx))
                
                # 8方向の角度判定
                if -22.5 < deg <= 22.5:
                    res["right"] = True
                elif 22.5 < deg <= 67.5:
                    res["right"] = res["down"] = True
                elif 67.5 < deg <= 112.5:
                    res["down"] = True
                elif 112.5 < deg <= 157.5:
                    res["left"] = res["down"] = True
                elif deg > 157.5 or deg <= -157.5:
                    res["left"] = True
                elif -157.5 < deg <= -112.5:
                    res["left"] = res["up"] = True
                elif -112.5 < deg <= -67.5:
                    res["up"] = True
                elif -67.5 < deg <= -22.5:
                    res["right"] = res["up"] = True
        return res

    def get_move_vector(self):
        """滑らかな全方向移動用（将来的に使うならこちら）"""
        m_pos = pygame.mouse.get_pos()
        m_pressed = pygame.mouse.get_pressed()[0]
        if not m_pressed: return (0, 0)

        dx = m_pos[0] - self.cx
        dy = m_pos[1] - self.cy
        dist = math.sqrt(dx**2 + dy**2)

        if 10 < dist < self.pad_radius:
            return (dx/dist, dy/dist)
        return (0, 0)

    def draw(self, screen):
        """コントローラーの描画"""
        pad_surf = pygame.Surface((800, 1500), pygame.SRCALPHA)
        m_pos = pygame.mouse.get_pos()
        m_pressed = pygame.mouse.get_pressed()[0]

        # 1. 土台
        pygame.draw.circle(pad_surf, (40, 40, 40, 150), (self.cx, self.cy), self.pad_radius)

        # 2. 扇状の光
        if m_pressed:
            dx = m_pos[0] - self.cx
            dy = m_pos[1] - self.cy
            if 10**2 < dx**2 + dy**2 < self.pad_radius**2:
                angle = math.atan2(dy, dx)
                # 45度(π/4)の範囲を計算
                start_angle = (math.floor((angle + math.pi/8) / (math.pi/4)) * (math.pi/4)) - math.pi/8
                points = [
                    (self.cx, self.cy),
                    (self.cx + math.cos(start_angle) * self.pad_radius, self.cy + math.sin(start_angle) * self.pad_radius),
                    (self.cx + math.cos(start_angle + math.pi/4) * self.pad_radius, self.cy + math.sin(start_angle + math.pi/4) * self.pad_radius)
                ]
                pygame.draw.polygon(pad_surf, (255, 255, 0, 150), points)

        # 3. 枠線とリング
        for i in range(8):
            angle = i * (math.pi / 4) + math.pi/8
            end_x = self.cx + math.cos(angle) * self.pad_radius
            end_y = self.cy + math.sin(angle) * self.pad_radius
            pygame.draw.line(pad_surf, (255, 255, 255, 100), (self.cx, self.cy), (end_x, end_y), 2)

        pygame.draw.circle(pad_surf, (255, 255, 255, 200), (self.cx, self.cy), self.pad_radius, 5)
        pygame.draw.circle(pad_surf, (255, 255, 255, 200), (self.cx, self.cy), 10)

        # 4. 矢印
        arrows = [("▲", 0, -150), ("▼", 0, 150), ("◀", -150, 0), ("▶", 150, 0)]
        for arrow, ox, oy in arrows:
            txt = self.font.render(arrow, True, (255, 255, 255, 180))
            pad_surf.blit(txt, txt.get_rect(center=(self.cx + ox, self.cy + oy)))

        screen.blit(pad_surf, (0, 0))
        
async def play_game(screen):
    # ★開始直後に一瞬だけ休ませる（ブラウザの読み込み待ち）
    await asyncio.sleep(0.1) 

    # --- 1. まず天気を一回だけ決める ---
    current_weather = get_time_weather()

    # --- フォント読み込み（ここで1回だけ行う） ---
    try:
        font_path = "assets/NotoSansJP-Regular.ttf"
        font_msg = pygame.font.Font(font_path, 80)   
        font_ui = pygame.font.Font(font_path, 40)    
        font_count = pygame.font.Font(font_path, 150) 
    except:
        font_msg = pygame.font.SysFont(None, 80)
        font_ui = pygame.font.SysFont(None, 40)
        font_count = pygame.font.SysFont(None, 150)

    # --- ゲーム用BGMの再生 ---
    try:
        pygame.mixer.music.load("assets/game_bgm.ogg")
        pygame.mixer.music.play(-1)
    except:
        pass

    # --- 2. 決まった天気を各クラスに渡す ---
    # Backgroundクラスを、引数で天気を受け取れるように少し修正します
    bg = Background(current_weather) 
    effect = WeatherEffect(current_weather) 
    player = Player()
    enemy = Enemy()
    controller = Controller()
    
    clock = pygame.time.Clock()
    score = 0
    speed_up_timer = 0 
    last_speed_check = 0 
    
    # 【修正ポイント】ここにあった SysFont(None, ...) の再定義を削除しました
    # これで上の日本語フォントがそのまま使われます
    
    start_ticks = pygame.time.get_ticks()

    while True:
        countdown = 3 - (pygame.time.get_ticks() - start_ticks) // 1000

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return "QUIT", 0
        
        # 入力を受け取る
        ctrl = controller.get_input()

        if countdown <= 0:
            # 十字キー/タップ操作の反映
            if ctrl["up"]:    player.rect.y -= player.speed
            if ctrl["down"]:  player.rect.y += player.speed
            if ctrl["left"]:  player.rect.x -= player.speed
            if ctrl["right"]: player.rect.x += player.speed
            
            player.update()
            enemy.update(player.rect)
            
            score += 1 / 60
            current_sec = int(score)

            # ★【追加】25秒でゲームクリア判定
            if current_sec >= 25:
                pygame.mixer.music.stop() # 音楽を止める
                await asyncio.sleep(0.5)  # クリアの余韻
                return "CLEAR", current_sec # "CLEAR" という状態を返す

            # スピードアップ処理
            if current_sec > 0 and current_sec % 10 == 0 and current_sec != last_speed_check:
                speed_up_timer = 90      
                last_speed_check = current_sec 

            # スコアに合わせて敵の速度を更新
            enemy.speed = 5 + (current_sec // 10)

        # 当たり判定
        offset_x = enemy.rect.x - player.rect.x
        offset_y = enemy.rect.y - player.rect.y
        if player.mask.overlap(enemy.mask, (offset_x, offset_y)) and player.invincible_timer <= 0:
            player.hp -= 1
            player.invincible_timer = 60
            if player.hp <= 0:
                pygame.mixer.music.stop()
                await asyncio.sleep(0.5)
                return "GAMEOVER", int(score)

        # --- 描画処理 ---
        bg.draw(screen)

        # ★追加：エフェクトの更新と描画
        effect.update()
        effect.draw(screen)

        player.draw(screen)
        enemy.draw(screen)
        controller.draw(screen)

        # スピードアップ演出
        if speed_up_timer > 0:
            msg_surf = pygame.Surface((800, 100), pygame.SRCALPHA)
            msg_surf.fill((50, 50, 50, 180)) 
            screen.blit(msg_surf, (0, 450))
            
            # 日本語フォントで描画
            txt = font_msg.render("スピードアップ！！", True, (255, 255, 0)) 
            screen.blit(txt, txt.get_rect(center=(400, 500)))
            speed_up_timer -= 1 

        # UI表示
        txt_ui = font_ui.render(f"体力:{player.hp}  スコア:{int(score)}秒", True, (255,255,255))
        screen.blit(txt_ui, (20,20))

        # カウントダウン演出
        if countdown > 0:
            overlay = pygame.Surface((800, 1500), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            screen.blit(overlay, (0, 0))
            count_surf = font_count.render(str(countdown), True, (255, 215, 0))
            screen.blit(count_surf, count_surf.get_rect(center=(400, 500)))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)
